<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login Admin - Restoran</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>
    <header>
        <h1>Login Admin Restoran</h1>
        <nav><a href="<?php echo e(route('pegawai.index')); ?>">&larr; Kembali ke Beranda</a></nav>
    </header>
    <hr>
    <main style="max-width: 400px; margin: 40px auto;">
        <h2>Silakan Masuk</h2>
        <?php if($errors->any()): ?>
            <p style="color: red;"><?php echo e($errors->first()); ?></p>
        <?php endif; ?>
        <form action="<?php echo e(route('login.proses')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <p>
                <label>Username:</label><br>
                <input type="text" name="username" value="<?php echo e(old('username')); ?>" required>
            </p>
            <p>
                <label>Password:</label><br>
                <input type="password" name="password" required>
            </p>
            <p>
                <button type="submit">Masuk</button>
            </p>
        </form>
    </main>
</body>
</html><?php /**PATH D:\xampp\htdocs\restoran\TUGASBESAR_M3_HAIKAL\resources\views/auth/login.blade.php ENDPATH**/ ?>