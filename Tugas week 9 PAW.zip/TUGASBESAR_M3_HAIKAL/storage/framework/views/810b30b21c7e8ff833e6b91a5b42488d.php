<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Pegawai - Restoran</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>
    <header>
        <h1>Form Edit Pegawai</h1>
        <nav>
            <a href="<?php echo e(route('pegawai.index')); ?>">&larr; Kembali ke Daftar Pegawai</a>
        </nav>
    </header>

    <hr>

    <main>
        <h2>Ubah Data Staff</h2>

        <form action="<?php echo e(route('pegawai.update', $pegawai->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <p>
                <label>Nama Lengkap:</label><br>
                <input type="text" name="nama" value="<?php echo e(old('nama', $pegawai->nama)); ?>" required>
            </p>
            
            <p>
                <label>Jabatan:</label><br>
                <select name="jabatan">
                    <option value="chef" <?php echo e($pegawai->jabatan == 'chef' ? 'selected' : ''); ?>>chef</option>
                    <option value="Waiter" <?php echo e($pegawai->jabatan == 'Waiter' ? 'selected' : ''); ?>>Waiter</option>
                    <option value="Kasir" <?php echo e($pegawai->jabatan == 'Kasir' ? 'selected' : ''); ?>>Kasir</option>
                </select>
            </p>

            <p>
                <label>Nomor Kontak:</label><br>
                <input type="number" name="nomor" value="<?php echo e(old('nomor', $pegawai->nomor)); ?>" required>
            </p>

            <p>
                <button type="submit">Simpan Perubahan</button>
            </p>
        </form>
    </main>

    <br><hr>

    <footer>
        <p>Sistem Restoran & Cafe - Modul Staff & Pegawai</p>
    </footer>
</body>
</html><?php /**PATH D:\xampp\htdocs\restoran\restoran-laravel\resources\views/pegawai/edit.blade.php ENDPATH**/ ?>