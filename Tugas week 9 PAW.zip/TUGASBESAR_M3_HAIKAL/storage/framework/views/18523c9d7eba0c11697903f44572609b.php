<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Modul Staff & Pegawai</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>
    <header>
        <h1>Manajemen Staff & Pegawai Restoran</h1>
        <nav style="margin-top: 10px;">
            <?php if(auth()->guard()->check()): ?>
                <span>Halo, <strong><?php echo e(Auth::user()->username); ?></strong></span> | 
                <form action="<?php echo e(route('logout')); ?>" method="POST" style="display:inline;">
                    <?php echo csrf_field(); ?>
                    <button type="submit" style="background:#e74c3c; color:white; border:none; padding:5px 10px; border-radius:4px; cursor:pointer;">Logout</button>
                </form>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" style="color: #1ef29d;">Login Admin</a>
            <?php endif; ?>
        </nav>
    </header>

    <hr>

    <main>
        <h2>Daftar Pegawai Restoran</h2>
        
        <?php if(auth()->guard()->check()): ?>
        <p>
            <a href="<?php echo e(route('pegawai.create')); ?>">+ Tambah Pegawai Baru</a>
        </p>
        <?php endif; ?>

        <?php if(session('success')): ?>
            <p style="color: green; font-weight: bold;"><?php echo e(session('success')); ?></p>
        <?php endif; ?>
        
        <table border="1" cellpadding="10" cellspacing="0">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Pegawai</th>
                    <th>Jabatan</th>
                    <th>Nomor Kontak</th>
                    <?php if(auth()->guard()->check()): ?>
                    <th>Aksi</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($d->nama); ?></td>
                    <td><?php echo e($d->jabatan); ?></td>
                    <td><?php echo e($d->nomor); ?></td>
                    <?php if(auth()->guard()->check()): ?>
                    <td>
                        <a href="<?php echo e(route('pegawai.edit', $d->id)); ?>" style="background: #f39c12; color: white; padding: 5px 10px; text-decoration: none; border-radius: 3px;">Edit</a>
                        <form action="<?php echo e(route('pegawai.destroy', $d->id)); ?>" method="POST" style="display:inline;" onsubmit="return confirm('Yakin mau hapus data ini?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" style="background: #e74c3c; color: white; border: none; padding: 5px 10px; border-radius: 3px; cursor: pointer;">Hapus</button>
                        </form>
                    </td>
                    <?php endif; ?>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </main>

    <br>
    <hr>

    <footer style="text-align: left;">
        <p>
            Nama: Haikal Hadamean Siregar
            <br>
            NIM: 102022500237
            <br>
            Kelas: SI-49-06
            <br>
            Kelompok 10
            <br>
            Modul: Modul Staff & Pegawai (Laravel)
        </p>
    </footer>
</body>
</html><?php /**PATH D:\xampp\htdocs\restoran\restoran-laravel\resources\views/pegawai/index.blade.php ENDPATH**/ ?>