<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login Admin - Restoran</title>
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
</head>
<body>
    <header>
        <h1>Login Admin Restoran</h1>
        <nav><a href="{{ route('pegawai.index') }}">&larr; Kembali ke Beranda</a></nav>
    </header>
    <hr>
    <main style="max-width: 400px; margin: 40px auto;">
        <h2>Silakan Masuk</h2>
        @if($errors->any())
            <p style="color: red;">{{ $errors->first() }}</p>
        @endif
        <form action="{{ route('login.proses') }}" method="POST">
            @csrf
            <p>
                <label>Username:</label><br>
                <input type="text" name="username" value="{{ old('username') }}" required>
            </p>
            <p>
                <label>Password:</label><br>
                <input type="password" name="password" required>
            </p>
            <p>
                <button type="submit">Masuk</button>
            </p>
        </form>
    </main>
</body>
</html>